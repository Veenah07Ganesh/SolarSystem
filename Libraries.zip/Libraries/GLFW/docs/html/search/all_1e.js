var searchData=
[
  ['x_20yosemite_20support_20is_20deprecated_0',['OS X Yosemite support is deprecated',['../news.html#yosemite_deprecated',1,'']]],
  ['x11_1',['Dependencies for Wayland and X11',['../compile_guide.html#compile_deps_wayland',1,'']]],
  ['x11_20empty_20events_20no_20longer_20round_20trip_20to_20server_2',['X11 empty events no longer round-trip to server',['../news.html#x11_emptyevent_caveat',1,'']]],
  ['x11_20extensions_20protocols_20and_20ipc_20standards_3',['X11 extensions, protocols and IPC standards',['../compat_guide.html#compat_x11',1,'']]],
  ['x11_20specific_20init_20hints_4',['X11 specific init hints',['../intro_guide.html#init_hints_x11',1,'']]],
  ['x11_20specific_20window_20hints_5',['X11 specific window hints',['../window_guide.html#window_hints_x11',1,'']]],
  ['x11_20vulkan_20window_20surface_20hint_6',['X11 Vulkan window surface hint',['../news.html#x11_xcb_vulkan_surface',1,'']]],
  ['xcode_20on_20macos_7',['With Xcode on macOS',['../build_guide.html#build_link_xcode',1,'']]],
  ['xp_8',['Support for versions of Windows older than XP',['../moving_guide.html#moving_windows',1,'']]],
  ['xp_20and_20vista_20support_20is_20deprecated_9',['Windows XP and Vista support is deprecated',['../news.html#winxp_deprecated',1,'']]]
];
